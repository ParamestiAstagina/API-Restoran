const AboutUs = {
    async render() {
      return `
        <h2>About Us</h2>
      `;
    },
   
    async afterRender() {
      // Fungsi ini akan dipanggil setelah render()
    },
  };
   
  export default AboutUs;